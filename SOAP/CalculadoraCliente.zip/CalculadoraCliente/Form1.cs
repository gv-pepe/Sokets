﻿using System;
using System.Windows.Forms;
using CalculadoraCliente.CalculadoraWSService;


namespace CalculadoraCliente
{
    public partial class Form1 : Form
    {
        private CalculadoraWSClient cliente;

        public Form1()
        {
            InitializeComponent();
            cliente = new CalculadoraWSClient();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Restar_Click(object sender, EventArgs e)
        {
            EjecutarOperacion("restar");
        }

        private void Multiplicar_Click(object sender, EventArgs e)
        {
            EjecutarOperacion("multiplicar");
        }

        private void Dividir_Click(object sender, EventArgs e)
        {
            EjecutarOperacion("dividir");
        }

        private void Contador_Click(object sender, EventArgs e)
        {
            try
            {
                int contador = cliente.getContadorPeticiones();
                resultadoArea.AppendText($"Número de operaciones realizadas: {contador}\n");
            }
            catch (Exception ex)
            {
                resultadoArea.AppendText($"Error al obtener el contador: {ex.Message}\n");
            }
        }

        private void Sumar_Click(object sender, EventArgs e)
        {
            EjecutarOperacion("sumar");
        }

        private void EjecutarOperacion(string operacion)
        {
            try
            {
                int a = int.Parse(textBoxA.Text);
                int b = int.Parse(textBoxB.Text);
                int resultado = 0;

                switch (operacion)
                {
                    case "sumar":
                        resultado = cliente.sumar(a, b);
                        break;
                    case "restar":
                        resultado = cliente.restar(a, b);
                        break;
                    case "multiplicar":
                        resultado = cliente.multiplicar(a, b);
                        break;
                    case "dividir":
                        resultado = cliente.dividir(a, b);
                        break;
                }

                resultadoArea.AppendText($"Resultado de {operacion}: {resultado}\n");
            }
            catch (FormatException)
            {
                resultadoArea.AppendText("Error: Entrada no válida\n");
            }
            catch (Exception ex)
            {
                resultadoArea.AppendText($"Error al realizar la operación: {ex.Message}\n");
            }
        }
    }
}